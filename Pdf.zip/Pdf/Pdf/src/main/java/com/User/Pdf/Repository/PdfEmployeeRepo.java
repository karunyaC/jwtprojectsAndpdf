package com.User.Pdf.Repository;

import com.User.Pdf.Model.PdfEmployeeDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface PdfEmployeeRepo extends JpaRepository<PdfEmployeeDetails, Integer> {

}
