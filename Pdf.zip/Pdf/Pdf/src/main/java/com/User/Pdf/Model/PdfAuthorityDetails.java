package com.User.Pdf.Model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "authority_detail")
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PdfAuthorityDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "officerid")
    private int cpdclId;

    @Column(name = "officername")
    private String officerName;

    @Column(name = "officerdesignation")
    private String officerDesignation;

    @Column(name="ddocode")
    private int ddoCode;

    @Column(name = "department")
    private String department;

    @Column(name = "office")
    private String office;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCpdclId() {
        return cpdclId;
    }

    public void setCpdclId(int cpdclId) {
        this.cpdclId = cpdclId;
    }

    public String getOfficerName() {
        return officerName;
    }

    public void setOfficerName(String officerName) {
        this.officerName = officerName;
    }

    public String getOfficerDesignation() {
        return officerDesignation;
    }

    public void setOfficerDesignation(String officerDesignation) {
        this.officerDesignation = officerDesignation;
    }

    public int getDdoCode() {
        return ddoCode;
    }

    public void setDdoCode(int ddoCode) {
        this.ddoCode = ddoCode;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }
}

