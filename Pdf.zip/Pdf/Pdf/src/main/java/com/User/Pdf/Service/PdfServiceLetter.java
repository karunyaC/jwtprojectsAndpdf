package com.User.Pdf.Service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;


@Service
public class PdfServiceLetter {

    @Autowired
    ResourceLoader resourceLoader;

    public ByteArrayOutputStream generatePdfs() {

        //ByteArrayOutputStream to hold the PDF data
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        try {
            Document document = new Document();

            document.open();
            PdfWriter.getInstance(document, byteArrayOutputStream);

            //Adding the logo in the beginning of the pdf
            addLogo(document, "classpath:/image/logo.png",40,770);




            // Declaring the fonts of the pdf
            float apcpdclFontSize = 11.0f;
            float subTitleFontSize = 8.0f;
            float bodyFontSize = 10.0f;
            float letterFontSize = 11.0f;
            float conclusionFontSize = 10.0f;

            // Set fonts styling
            Font apcpdclFont = new Font(Font.FontFamily.COURIER, apcpdclFontSize, Font.BOLD);
            Font subTitleFont = new Font(Font.FontFamily.COURIER, subTitleFontSize, Font.BOLD);
            Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, bodyFontSize, Font.NORMAL);
            Font letterFont = new Font(Font.FontFamily.TIMES_ROMAN, letterFontSize, Font.BOLD);
            Font conclusionFont = new Font(Font.FontFamily.TIMES_ROMAN, conclusionFontSize, Font.NORMAL);


            //Title of APCPDCL
            String title1 = "Andhra Pradesh Central Power Distribution Corporate Limited";

            Paragraph title = new Paragraph(title1, apcpdclFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            String sub_title = "(A Govt of A.P Enterprise & An ISO 9001:2015 & ISO 27001:2013 Certified Company)\n";

            Paragraph subTitle = new Paragraph(sub_title, subTitleFont);
            subTitle.setAlignment(Element.ALIGN_CENTER);
            document.add(subTitle);

            String credit_card = "\nCREDIT CARD FOR TREATMENT";

            Paragraph creditCard = new Paragraph(credit_card, letterFont);
            creditCard.setAlignment(Element.ALIGN_CENTER);
            document.add(creditCard);

            String serial = "Credit card Serial No. MED161124135442";

            Paragraph creditSerial = new Paragraph(serial, apcpdclFont);
            creditSerial.setAlignment(Element.ALIGN_CENTER);
            document.add(creditSerial);

            String letterNO = "E-366767/EPCOR-06003(41)/32/2021-IR ";
            String fullDate = ".16-11-2024";
            String letter_no = "Letter.No."+letterNO+"MEDICAL-COR/Dt."+fullDate;

            Paragraph letterNo = new Paragraph(letter_no, letterFont);
            letterNo.setAlignment(Element.ALIGN_CENTER);
            document.add(letterNo);

            String fromDesignation = "The Chief General Manager(HRD),\n";
            String fromOffice = "Corporate Office,\n";
            String fromCompany = "APCPDCL\n";
            String fromLocation = "Visakhapatnam.\n";

            String fromAddress = fromDesignation+fromOffice+fromCompany+fromLocation;

            Paragraph from = new Paragraph("From",letterFont);
            document.add(from);
            Paragraph from2 = new Paragraph(fromAddress,bodyFont);
            document.add(from2);

            String toDesignation = "The Chief General Manager(HRD),\n";
            String toOffice = "Corporate Office,\n";
            String toCompany = "APCPDCL\n";
            String toLocation = "Visakhapatnam.\n";

            String toAddress = toDesignation+toOffice+toCompany+toLocation;

            Paragraph to = new Paragraph("To",letterFont);
            document.add(to);
            Paragraph to2 = new Paragraph(toAddress,bodyFont);
            document.add(to2);

            String ref = "Ref : Your Letter Dated: 16-Nov-2024";
            Paragraph refData = new Paragraph(ref,letterFont);
            refData.setAlignment(Element.ALIGN_CENTER);
            document.add(refData);

            //Details table
            PdfPTable addressTable = new PdfPTable(3);
            addressTable.setWidths(new float[]{100f,10f,100f});
            addressTable.getDefaultCell()
                    .setBorder(0);


            //'From' and 'To' addresses into the table
            addressTable.addCell(new Phrase("Name of the Patient ", bodyFont));
            addressTable.addCell(new Phrase(":", bodyFont));
            addressTable.addCell(new Phrase("RAMANA V V", bodyFont));

            addressTable.addCell(new Phrase("Relation to the Employee ", bodyFont));
            addressTable.addCell(new Phrase(":", bodyFont));
            addressTable.addCell(new Phrase("SELF", bodyFont));

            addressTable.addCell(new Phrase("Name of the Employee(Employee ID) ", bodyFont));
            addressTable.addCell(new Phrase(":", bodyFont));
            addressTable.addCell(new Phrase("RAMANA V V (1019102)", bodyFont));

            addressTable.addCell(new Phrase("Designation", bodyFont));
            addressTable.addCell(new Phrase(":", bodyFont));
            addressTable.addCell(new Phrase("WATCHMAN", bodyFont));

            addressTable.addCell(new Phrase("Office of the Employee", bodyFont));
            addressTable.addCell(new Phrase(":", bodyFont));
            addressTable.addCell(new Phrase("CORPORATE OFFICE", bodyFont));

            addressTable.addCell(new Phrase("Admission I.P No & Date", bodyFont));
            addressTable.addCell(new Phrase(":", bodyFont));
            addressTable.addCell(new Phrase("MC50IP24110325 & 16-Nov-2024", bodyFont));

            addressTable.addCell(new Phrase("Disease", bodyFont));
            addressTable.addCell(new Phrase(":", bodyFont));
            addressTable.addCell(new Phrase("SHORTNESS OF BREATH UNDER  EVALUATION WITH REACTIVE AIRWAY DISEASE", bodyFont));

            addressTable.addCell(new Phrase("Eligibility Amount", bodyFont));
            addressTable.addCell(new Phrase(":", bodyFont));
            addressTable.addCell(new Phrase("Rs.86,000/- (Rupees Eighty Six Thousand)", bodyFont));

            document.add(addressTable);

            String desc = """
                    2)The above Credit card is issued with the approval of Competent authority
                    3) Over and above eligibility amount may be collected from employee and APCPDCL (Board) will not accept any responsibility for excess amount billed.
                    4) Eligibility of Accommodation as per CGHS Tariff: General Ward per day.
                    5) Validity of Card: for one admission only for one month from the date of admission.
                    For any over stayal an extension card has to be applied for continuous treatment.
                    """;
            Paragraph description = new Paragraph(desc,bodyFont);
            document.add(description);

            String note = "Note:-";
            Paragraph Note = new Paragraph(note,letterFont);
            document.add(Note);


            String note1 = """
                    i) Bill may be sent in duplicate along with discharge summary and copy of Case Sheet.No bill will be accepted for payment without producing discharge summary, copy if Case Sheet and signature of the Patient / Attendant. Also, the bank account details of the hospital should be furnished.
                    ii) A copy of the Bill may also be issued to employee along with discharge summary.
                    iii) The Estimation for Credit Card and bills should be send with full Details and Particular as per CGHS-2014 Tariff Rates with code numbers and the Certificate regarding Non-NABH/NABL or NABH/NABI, in term of the orders issued vide E.O.O.(HRD) Ms. No.82, Dt.12.05.15.
                    iv) Also, the bank account details of the Hospital should be furnished.
                    """;
            Paragraph Note1 = new Paragraph(note1,bodyFont);
            document.add(Note1);

            String faith = "Yours faithFully,";
            Paragraph Faith = new Paragraph(faith,bodyFont);
            Faith.setIndentationLeft(320);
            document.add(Faith);

            String digital = "(Digital Signed using OTP Authentication)";
            Paragraph Digital = new Paragraph(digital,bodyFont);
            Digital.setIndentationLeft(300);
            document.add(Digital);

            String faith_fully = """
                    SUMAN KALYANI(1019102)
                    Designation: CHIEF GENERAL MANAGER
                    Date: Fri Nov 22 16:13:41 IST 2024""";
            Paragraph faithFully = new Paragraph(faith_fully, letterFont);
            faithFully.setIndentationLeft(260);
            document.add(faithFully);

            String sign = "SIGNATURE OF THE OFFICER";
            Paragraph Sign = new Paragraph(sign,bodyFont);
            Sign.setIndentationLeft(300);
            document.add(Sign);

            String copy = "Copy to";
            Paragraph Copy = new Paragraph(copy,letterFont);
            document.add(Copy);

            String conclusion = """
                    RAMANA V V (1019102), WATCHMAN, CORPORATE OFFICE
                    HE EXECUTIVE ENGINEER, CORPORATE OFFICE""";
            document.add(new Paragraph(conclusion, conclusionFont));

            String file = """
                    The Stock file
                    Self Funding Medical Scheme""";
            document.add(new Paragraph(file, bodyFont));

            document.close();

        }

        catch (Exception e) {
            throw new RuntimeException(e);
        }

        return byteArrayOutputStream;
    }
    private void addLogo(Document document, String logoPath, float x, float y) throws Exception {
        Resource logoResource = resourceLoader.getResource(logoPath);
        if (logoResource.exists()) {
            Image logo = Image.getInstance(logoResource.getInputStream().readAllBytes());
            logo.scaleToFit(100, 50);
            logo.setAbsolutePosition(x, y);
            document.add(logo);
        }
        else {
            throw new Exception("Logo not found at path: " + logoPath);
        }
    }
}