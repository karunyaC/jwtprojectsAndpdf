package com.User.Pdf.Model;

import jakarta.persistence.*;
import lombok.*;
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "test_detail")
public class PdfEmployeeDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "empid")
    private int patientId;

    @Column(name = "empname")
    private String employeeName;

    @Column(name = "patientname")
    private String patientName;

    @Column(name = "relation")
    private String relation;

    @Column(name = "empdesignation")
    private String patientDesignation;

    @Column(name ="office")
    private String office;

    @Column(name = "admission_ip")
    private String admission_Ip;

    @Column(name = "disease")
    private String disease;

    @Column(name = "amount")
    private String amount;

    @Column(name = "totalamount")
    private String totalAmount;

    @Column(name = "additionalAmount")
    private String additionalAmount;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        employeeName = employeeName;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }


    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getAdmission_Ip() {
        return admission_Ip;
    }

    public void setAdmission_Ip(String admission_Ip) {
        this.admission_Ip = admission_Ip;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPatientDesignation() {
        return patientDesignation;
    }

    public void setPatientDesignation(String patientDesignation) {
        this.patientDesignation = patientDesignation;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getAdditionalAmount() {
        return additionalAmount;
    }

    public void setAdditionalAmount(String additionalAmount) {
        this.additionalAmount = additionalAmount;
    }
}
