package com.User.Pdf.Repository;

import com.User.Pdf.Model.PdfHospitalDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PdfHospitalRepo extends JpaRepository<PdfHospitalDetails,Integer> {

}
