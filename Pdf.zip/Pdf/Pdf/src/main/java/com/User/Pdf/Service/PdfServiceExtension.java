package com.User.Pdf.Service;

import com.User.Pdf.Model.PdfEmployeeDetails;
import com.User.Pdf.Model.PdfHospitalDetails;
import com.User.Pdf.Repository.PdfEmployeeRepo;
import com.User.Pdf.Repository.PdfForwardEmpRepo;
import com.User.Pdf.Repository.PdfHospitalRepo;
import com.User.Pdf.Response.EmployeeAndOfficerDetailsRes;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfPTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;


@Service
public class PdfServiceExtension {

    @Autowired
    ResourceLoader resourceLoader;

    @Autowired
    PdfForwardEmpRepo pdfForwardEmpRepo;

    @Autowired
    PdfHospitalRepo pdfHospitalRepo;

    @Autowired
    PdfEmployeeRepo pdfEmployeeRepo;

    public ByteArrayOutputStream generatePdf() {

        //ByteArrayOutputStream to hold the PDF data
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        List<EmployeeAndOfficerDetailsRes> employee = pdfForwardEmpRepo.finByType();
        if (employee.isEmpty()) {
            throw new RuntimeException("Employee Not Found: ");
        }
        PdfEmployeeDetails pdfEmployeeDetails = pdfEmployeeRepo.findById(1).get();

        PdfHospitalDetails pdfHospitalDetails =pdfHospitalRepo.findById(1).get();

        try {
            //New document
            Document document = new Document();
            PdfWriter.getInstance(document, byteArrayOutputStream);

            document.open();  // Open the document for writing

            //Adding the logo in the beginning of the pdf
            addLogo(document, "classpath:/image/logo.png", 40, 770);

            // Declaring the fonts of the pdf
            float apcpdclFontSize = 11.0f;
            float subTitleFontSize = 8.0f;
            float bodyFontSize = 10.0f;
            float letterFontSize = 11.0f;
            float conclusionFontSize = 10.0f;

            // Set fonts styling
            Font apcpdclFont = new Font(Font.FontFamily.COURIER, apcpdclFontSize, Font.BOLD);
            Font subTitleFont = new Font(Font.FontFamily.COURIER, subTitleFontSize, Font.BOLD);
            Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, bodyFontSize, Font.NORMAL);
            Font letterFont = new Font(Font.FontFamily.TIMES_ROMAN, letterFontSize, Font.BOLD);
            Font conclusionFont = new Font(Font.FontFamily.TIMES_ROMAN, conclusionFontSize, Font.NORMAL);

            //Title of APCPDCL
            String title1 = "Andhra Pradesh Central Power Distribution Corporate Limited\n";


            Paragraph title = new Paragraph(title1, apcpdclFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);


            String sub_title = "(A Govt of A.P Enterprise & An ISO 9001:2015 & ISO 27001:2013 Certified Company)  \n" +
                    "____________________________________________________________________________________________________________\n";

            Paragraph subTitle = new Paragraph(sub_title, subTitleFont);
            subTitle.setAlignment(Element.ALIGN_CENTER);
            document.add(subTitle);

            String credit_card = "CREDIT CARD FOR TREATMENT\n\n";

            Paragraph creditCard = new Paragraph(credit_card, letterFont);
            creditCard.setAlignment(Element.ALIGN_CENTER);
            document.add(creditCard);

            // This is for the (From: and To) Address

            String fromAddress = "The "+employee.getFirst().getAuthorityDesignation()+" (HRD)\n"+employee.getFirst().getAuthorityOffice()+"\n"+employee.getFirst().getAuthorityDepartment()+"\n"+employee.getFirst().getAuthorityLocation();
            String toAddress = pdfHospitalDetails.getDirector()+",\n"+pdfHospitalDetails.getHospitalName()+",\n"+pdfHospitalDetails.getLocation()+",\n"+pdfHospitalDetails.getEmail();

            //table for the 'From' and 'To' addresses side by side
            PdfPTable addressTable = new PdfPTable(2);
            addressTable.setWidths(new float[]{20f, 60f});
            addressTable.getDefaultCell()
                    .setBorder(0);


            //'From' and 'To' addresses into the table
            addressTable.addCell(new Phrase("From :\n" + fromAddress, bodyFont));
            addressTable.addCell(new Phrase("To :\n" + toAddress, bodyFont));

            document.add(addressTable);

            String letterNO = "E-"+random6()+"/EPCOR-"+random5()+"(41)/32/2021-IR ";
            String letter_no = "Letter.No." + letterNO + "MEDICAL-COR/Dt."+getDate()+"\n"+getDateEmployee()+pdfEmployeeDetails.getPatientId()+"\nDt:" + getDate();

            Paragraph letterNo = new Paragraph(letter_no, letterFont);
            letterNo.setAlignment(Element.ALIGN_CENTER);
            document.add(letterNo);


            String serial = "Credit card Serial No. MED"+random12()+"(Extn. CC No. 1)\n\n";

            Paragraph creditSerial = new Paragraph(serial, letterFont);
            creditSerial.setAlignment(Element.ALIGN_CENTER);
            document.add(creditSerial);

            //Paragraph for Subject and Reference
            PdfPTable sirSub = new PdfPTable(2);
            sirSub.setWidths(new float[]{5f, 60f});
            sirSub.getDefaultCell()
                    .setBorder(0);

            String subject = "\nAPCPDCL-CORP-" + pdfEmployeeDetails.getEmployeeName() + "(EMP ID NO " + pdfEmployeeDetails.getPatientId() + ")" + pdfEmployeeDetails.getPatientDesignation() + "-Issued" +
                    " Extension Medical Credit Card-Reg.";

            sirSub.addCell(new Phrase("Sir,", letterFont));
            sirSub.addCell(new Phrase("", bodyFont));
            sirSub.addCell(new Phrase(" Sub:-", letterFont));
            sirSub.addCell(new Phrase(subject, bodyFont));


            sirSub.addCell(new Phrase(" Ref:-", letterFont));
            String reference = "Letter.No.E-"+random6()+"/EPCOR-06003(41)/32/2021-IR MEDICAL-COR/Dt."+getDate();
            sirSub.addCell(new Phrase(reference, bodyFont));


            document.add(sirSub);


            String desc_Sub = "(EXTENSION MEDICAL CREDIT CARD(1st time) FOR TREATMENT)\n*****\n";

            Paragraph descSub = new Paragraph(desc_Sub, letterFont);
            descSub.setAlignment(Element.ALIGN_CENTER);
            document.add(descSub);


            String paragraph1 = "In continuation to this office letter 1st wherein Credit card issued" +
                    " for an amount of Rs." + pdfEmployeeDetails.getAmount()+"with the approval" +
                    " of competent authority, this is to authorize that in respect of Sri "+pdfEmployeeDetails.getEmployeeName()+"," +
                    " [EMP ID "+pdfEmployeeDetails.getPatientId()+ "] "+pdfEmployeeDetails.getPatientDesignation()+", who has already been admitted vide" +
                    " IP No. "+pdfEmployeeDetails.getAdmission_Ip()+", "+getDate()+" for the treatment on credit basis in the" +
                    " Hospital for "+pdfEmployeeDetails.getDisease()+"may be stayed for further treatment.";
            String paragraph2 = "\n2)The authorization is valid in continuation to one month, for one admission" +
                    " only, from the date of admission for treatment as In-Patient only, for an amount" +
                    " of "+pdfEmployeeDetails.getAdditionalAmount()+"/- (Rupees  Only). If the amount of the total bill" +
                    " exceeds Rs."+pdfEmployeeDetails.getTotalAmount()+"/- (Rupees "+pdfEmployeeDetails.getAmount()+"/- + Rs. "+pdfEmployeeDetails.getAdditionalAmount()+"/-]," +
                    " the A.P.C.P.D.C. Ltd will pay only Rs."+pdfEmployeeDetails.getTotalAmount()+"/- (Rupees " +
                    " and the excess amount, if any, shall be collected from the patient." +
                    " The other terms and conditions are unaltered as per A.P.C.P.D.C. Ltd's letter 1st cited.";

            document.add(new Paragraph(paragraph1, bodyFont));
            document.add(new Paragraph(paragraph2, bodyFont));

            String faith_fully = "\n\nYour Faithfully,\n" + employee.getFirst().getAuthorityName()+"("+employee.getFirst().getAuthorityId() +")\nDesignation: " + employee.getFirst().getAuthorityDesignation() + "\nDate:"+getCurrentDate();
            Paragraph faithFully = new Paragraph(faith_fully, letterFont);
            faithFully.setIndentationLeft(260);
            document.add(faithFully);

            String copy = "Copy to,";
            String conclusion = pdfEmployeeDetails.getEmployeeName() + "," + pdfEmployeeDetails.getEmployeeName() + ", " + pdfEmployeeDetails.getOffice();
            String conclusion1 = "THE " + employee.getFirst().getOfficerDesignation() + ", " + employee.getFirst().getOfficerOffice();

            document.add(new Paragraph(copy,apcpdclFont));
            document.add(new Paragraph(conclusion, conclusionFont));
            document.add(new Paragraph(conclusion1, conclusionFont));

            String file = "\n\nThe Stock file\nSelf Funding Medical Scheme";
            document.add(new Paragraph(file, letterFont));


            document.close();

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

        return byteArrayOutputStream;
    }

    private void addLogo(Document document, String logoPath, float x, float y) throws Exception {
        Resource logoResource = resourceLoader.getResource(logoPath);
        if (logoResource.exists()) {
            Image logo = Image.getInstance(logoResource.getInputStream().readAllBytes());
            logo.scaleToFit(100, 50);
            logo.setAbsolutePosition(x, y);
            document.add(logo);
        } else {
            throw new Exception("Logo not found at path: " + logoPath);
        }
    }
    public String amountValue(String number){

        DecimalFormat formatter = new DecimalFormat("#,###");

        return formatter.format(number);
    }

    public static String getDate() {

        LocalDate currentDate = LocalDate.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        return currentDate.format(formatter);
    }

    public static String getDateEmployee() {

        LocalDate currentDate = LocalDate.now();

        DateTimeFormatter formatterEmployee = DateTimeFormatter.ofPattern("ddMMyyyy");

        return currentDate.format(formatterEmployee);
    }

    public int random6(){

        Random random = new Random();
        return 100000+random.nextInt(9000000);
    }

    public int random5(){

        Random random = new Random();
        return 10000+random.nextInt(900000);
    }

    public long random12(){

        Random random = new Random();

        return 100000000000L+(long)(random.nextLong()*900000000000L);
    }
    public static String getCurrentDate() {
        // Create a SimpleDateFormat with the desired pattern
        SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");

        // Set the time zone to IST (Indian Standard Time)
        sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));

        // Get the current date and format it
        Date now = new Date();
        return sdf.format(now);
    }
}