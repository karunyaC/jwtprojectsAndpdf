package com.User.Pdf.Controller;

import com.User.Pdf.Service.PdfServiceExtension;
import com.User.Pdf.Service.PdfServiceLetter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

@RestController
@RequestMapping("/pdf")
public class PdfController {

    @Autowired
    private PdfServiceExtension pdfService;

    @Autowired
    private PdfServiceLetter pdfServices;

    //The pdf data is inserted by the Runtime.
    @GetMapping("/download")
    public ResponseEntity<byte[]> generatePdf() {

        // Here we are generating PDF with dynamic data and font sizes.
        ByteArrayOutputStream pdfBytes = pdfService.generatePdf();

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Testing1.pdf"); // here the file will be downloaded.
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE); // The file type is .Pdf

        // Returning the PDF as a byte array Because The response is Pdf file.
        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes.toByteArray());
    }
    @GetMapping("/downloads")
    public ResponseEntity<byte[]> generatePdfs() throws IOException {

        // Here we are generating PDF with dynamic data and font sizes.
        ByteArrayOutputStream pdfBytes = pdfServices.generatePdfs();

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Testing2.pdf"); // here the file will be downloaded.
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE); // The file type is .Pdf

        // Returning the PDF as a byte array Because The response is Pdf file.
        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes.toByteArray());
    }
}
