package com.User.Pdf.Model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "officer_detail")
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PdfForwardEmployeeDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "officerid")
    private int employeeId;

    @Column(name = "officername")
    private String employeeName;

    @Column(name = "officerdesignation")
    private String employeeDesignation;

    @Column(name ="office")
    private String office;

    @Column(name = "department")
    private String department;

    @Column(name = "ddocode")
    private int ddocode;

    @Column(name = "forwardingofficer")
    private String forwardingOfficer;

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeDesignation() {
        return employeeDesignation;
    }

    public void setEmployeeDesignation(String employeeDesignation) {
        this.employeeDesignation = employeeDesignation;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getDdocode() {
        return ddocode;
    }

    public void setDdocode(int ddocode) {
        this.ddocode = ddocode;
    }

    public String getForwardingOfficer() {
        return forwardingOfficer;
    }

    public void setForwardingOfficer(String forwardingOfficer) {
        this.forwardingOfficer = forwardingOfficer;
    }
}

