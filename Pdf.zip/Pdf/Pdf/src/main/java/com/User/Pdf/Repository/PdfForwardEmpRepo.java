package com.User.Pdf.Repository;

import com.User.Pdf.Model.PdfForwardEmployeeDetails;
import com.User.Pdf.Response.EmployeeAndOfficerDetailsRes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface PdfForwardEmpRepo extends JpaRepository<PdfForwardEmployeeDetails, Integer> {


    @Query(nativeQuery = true,value = "select o.officerid as officerId,o.officername as officerName,o.officerdesignation as officerDesignation,\n" +
            "o.office as officerOffice, a.authorityid as authorityId,a.authorityname as authorityName,\n" +
            "a.authoritydesignation as authorityDesignation,a.office as authorityOffice,\n" +
            "a.department as authorityDepartment,a.location as authorityLocation from officer_detail o \n" +
            "left join authority_detail a on o.ddocode = a.ddocode;")
    List<EmployeeAndOfficerDetailsRes> finByType();

}
