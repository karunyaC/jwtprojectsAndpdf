package com.User.Pdf.Repository;

import com.User.Pdf.Model.PdfAuthorityDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface PdfAuthorityRepo extends JpaRepository<PdfAuthorityDetails, Integer> {

}
