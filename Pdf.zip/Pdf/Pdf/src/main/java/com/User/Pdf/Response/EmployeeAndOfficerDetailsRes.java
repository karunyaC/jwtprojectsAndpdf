package com.User.Pdf.Response;


public interface EmployeeAndOfficerDetailsRes {

    public Integer getOfficerId();
    public String getOfficerName();
    public String getOfficerDesignation();
    public String getOfficerOffice();

    public Integer getAuthorityId();
    public String getAuthorityName();
    public String getAuthorityDesignation();
    public String getAuthorityOffice();
    public String getAuthorityDepartment();
    public String getAuthorityLocation();
}
