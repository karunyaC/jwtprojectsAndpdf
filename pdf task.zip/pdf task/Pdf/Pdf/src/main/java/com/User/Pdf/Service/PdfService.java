package com.User.Pdf.Service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
//import com.lowagie.text.pdf.PdfTable;
import com.itextpdf.text.pdf.PdfPTable;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;

@Service
public class PdfService {

        public ByteArrayOutputStream generatePdf1() {

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                try {

                        Document document = new Document();
                        PdfWriter.getInstance(document, byteArrayOutputStream);

                        document.open();

                        float titleFontSize = 11.0f;
                        float subTitleFontSize = 8.0f;
                        float bodyFontSize = 10.0f;
                        float conclusionFontSize = 10.0f;

                        Font titleFont = new Font(Font.FontFamily.COURIER, titleFontSize, Font.BOLD);
                        Font subTitleFont = new Font(Font.FontFamily.COURIER, subTitleFontSize, Font.BOLD);
                        Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, bodyFontSize, Font.NORMAL);
                        Font conclusionFont = new Font(Font.FontFamily.TIMES_ROMAN, conclusionFontSize, Font.NORMAL);

                        String title1 = "Andhra Pradesh Central Power Distribution Corporate Limited\n";

                        Paragraph title = new Paragraph(title1, titleFont);
                        title.setAlignment(Element.ALIGN_CENTER);
                        document.add(title);

                        String sub_title = "A Govt of A.P Enterprise & An ISO 9001:2015 & ISO @&001:2013 Certified Company\n"
                                        + "_____________________________________________________________________________________________________";

                        Paragraph subTitle = new Paragraph(sub_title, subTitleFont);
                        subTitle.setAlignment(Element.ALIGN_CENTER);
                        document.add(subTitle);

                        String credit = "CREDIT CARD FOR TREATMENT";
                        Paragraph creditCard = new Paragraph(credit, titleFont);
                        creditCard.setAlignment(Element.ALIGN_CENTER);
                        document.add(creditCard);
                        String from = "The Chief General\n" +
                                        "Manager (HRD)\n" +
                                        "Corporate Office\n" +
                                        "APCPDCL\n" +
                                        "Vijayawada";
                        String to = "The Director\n" +
                                        "M/S TIRUMALA MEDICOVER HOSPITALS\n" +
                                        "(SAHRUDHAYA HEALTHCARE VIJAYAWADA),\n" +
                                        "VIJAYAWADA\n" +
                                        "operatios.vzm@medicoverhospitals.in";

                        Paragraph fromAddress = new Paragraph("From:\n" + from, bodyFont);
                        fromAddress.setLeading(17f);
                        fromAddress.setAlignment(Element.ALIGN_LEFT);
                        document.add(fromAddress);

                        Paragraph toHead = new Paragraph("To\n", bodyFont);
                        toHead.setAlignment(Element.ALIGN_RIGHT);
                        toHead.setSpacingBefore(-100);
                        toHead.setIndentationRight(364);

                        document.add(toHead);

                        Paragraph toAddress = new Paragraph(to, bodyFont);
                        toAddress.setAlignment(Element.ALIGN_JUSTIFIED);
                        toAddress.setSpacingBefore(-5);
                        toAddress.setLeading(17f);
                        toAddress.setIndentationLeft(150);

                        document.add(toAddress);

                        String letter = "\nLetter.No.E-366767/EPCOR-06003(41)/32/2021-IR MEDICAL-COR/Dt.22-11-2024202411221019102"
                                        +
                                        "Dt: 22-11-2024";
                        Paragraph letterHead = new Paragraph(letter, titleFont);
                        letterHead.setAlignment(Element.ALIGN_CENTER);
                        document.add(letterHead);

                        String serial = "Credit card Serial No.MED161124135442(Extn.CC No.1)";
                        Paragraph creditSerial = new Paragraph(serial, titleFont);
                        creditSerial.setAlignment(Element.ALIGN_CENTER);
                        document.add(creditSerial);
                        String sir = "";
                        PdfPTable sirTab = new PdfPTable(1);
                        sirTab.setWidthPercentage(100);
                        sirTab.getDefaultCell().setBorder(0);

                        sirTab.addCell(new Phrase("\nSir,\n" + sir, bodyFont));
                        Chunk indentChunk = new Chunk("     ");
                        Phrase phrase = new Phrase(indentChunk);
                        phrase.add(new Phrase(
                                        "Sub:- APCPDCL-CORP- RAMANA V V, RAMANA V V (Emp ID No 1019102) WATCHMAN-Issued Extension "
                                                        + "Medical Credit Card-Reg.,\n" + sir,
                                        bodyFont));
                        sirTab.addCell(phrase);

                        sirTab.addCell(new Phrase("         Ref-l,\n" + sir, bodyFont));
                        document.add(sirTab);

                        PdfPTable sirTab1 = new PdfPTable(1);
                        sirTab1.setWidthPercentage(100);
                        sirTab1.getDefaultCell().setBorder(0);

                        sirTab1.addCell(new Phrase("", bodyFont));
                        sirTab1.addCell(new Phrase(
                                        " APEPDCL-CORP- RAMANA V V, RAMANA V V (Emp ID No 1019102) WATCHMAN-Issued Extension Medical Credit Card-Reg.\n",
                                        bodyFont));
                        sirTab1.addCell(new Phrase(
                                        "Letter.No.E-366767/EPCOR-06003(41)/32/2021-IR MEDICAL-COR/Dt.16-11-2024\n",
                                        bodyFont));
                        document.add(sirTab1);

                        String extension = "(EXTENSION MEDICAL CREDIT CARD (1st time) FOR TREATMENT)";
                        Paragraph extension1 = new Paragraph(extension, titleFont);
                        extension1.setAlignment(Element.ALIGN_CENTER);
                        document.add(extension1);

                        String continution = "In continuation to this office letter 1st wherein Credit card issued for an amount c Rs.86000 (Rupees Eighty Six Thousand Only), with the approval of competent authority this is to authorize that in respect of Sri RAMANA V V, [EMP ID 1019102] WATCHMΜΑΝ who has already been admitted vide IP No. MC50IP24110325, Dt. 16-11-2024 for th treatment on credit basis in the Hospital for \"SHORTNESS OF BREATH UNDER EVALUATION WITH REACTIVE AIRWAY DISEASE\" may be stayed for furthe treatment.\n\n";
                        Paragraph continution1 = new Paragraph(continution, bodyFont);
                        document.add(continution1);

                        String authorization = "2) The authorization is valid in continuation to one month, for one admission only, from th date of admission for treatment as In-Patient only, for an amount of Rs.34000/- (Rupee Thirty Four Thousand Only). If the amount of the total bill exceeds Rs.120000/- (Rupee One Lakh Twenty Thousand Only) [Rs. 86000/- + Rs. 34000/-], the A.P.E.P.D.C.Ltd wil pay only Rs. 120000/- (Rupees One Lakh Twenty Thousand Only) and the excess amount, any, shall be collected from the patient. The other terms and conditions are unaltered as pe A.P.E.P.D.C.Ltd's letter 1st cited.\n";
                        Paragraph authorization1 = new Paragraph(authorization, bodyFont);
                        document.add(authorization1);

                        String faithfully = "\n Yours faithfully,\n";
                        Paragraph faithfully1 = new Paragraph(faithfully, bodyFont);
                        BaseColor thickGreen = new BaseColor(0, 128, 0);
                        Font boldFont = new Font(bodyFont.getFamily(), bodyFont.getSize(), Font.BOLD);
                        Chunk nameAndDetails = new Chunk(
                                        "SUMAN KALYANI D (1019083)\n Designation: CHIEF GENERAL MANAGER \n Date: Fri Nov 22 16:13:41 IST 2024",
                                        boldFont);
                        nameAndDetails
                                        .setFont(new Font(bodyFont.getFamily(), bodyFont.getSize(), bodyFont.getStyle(),
                                                        thickGreen));
                        faithfully1.setAlignment(Element.ALIGN_JUSTIFIED);
                        faithfully1.setSpacingBefore(-10);
                        faithfully1.setIndentationLeft(300);
                        faithfully1.add(nameAndDetails);
                        document.add(faithfully1);

                        String copyhead = "\n\n\n Copy to";
                        Paragraph copyhead1 = new Paragraph(copyhead, titleFont);
                        document.add(copyhead1);

                        String copy = "\n RAMANA V V (1019102), WATCHMAN, CORPORATE OFFICE \n THE EXECUTIVE ENGINEER, CORPORATE OFFICE";
                        Paragraph copy1 = new Paragraph(copy, bodyFont);
                        document.add(copy1);

                        String stock = "\n \n \n The Stock file \n Self Funding Medical Scheme";
                        Paragraph stock1 = new Paragraph(stock, bodyFont);
                        document.add(stock1);

                        document.close();

                } catch (DocumentException e) {
                        System.out.println("Occurred error an while generate the pdf file......!");
                }

                return byteArrayOutputStream;
        }
}
