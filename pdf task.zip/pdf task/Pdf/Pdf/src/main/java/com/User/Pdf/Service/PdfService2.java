package com.User.Pdf.Service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPCell;
import com.User.repo.UserDetailsRepository;
import com.User.Pdf.entity.UserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Optional;

@Service
public class PdfService2 {

        @Autowired
        private UserDetailsRepository userDetailsRepository;

        @Autowired
        private ResourceLoader resourceLoader;

        public ByteArrayOutputStream generatePdf(Long patientId) throws MalformedURLException, IOException {

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                try {

                        Document document = new Document();
                        PdfWriter.getInstance(document, byteArrayOutputStream);

                        document.open();

                        float titleFontSize = 11.0f;
                        float subTitleFontSize = 6.0f;
                        float bodyFontSize = 8.0f;
                        float conclusionFontSize = 10.0f;

                        Font titleFont = new Font(Font.FontFamily.COURIER, titleFontSize, Font.BOLD);
                        Font subTitleFont = new Font(Font.FontFamily.COURIER, subTitleFontSize, Font.BOLD);
                        Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, bodyFontSize, Font.NORMAL);
                        Font conclusionFont = new Font(Font.FontFamily.TIMES_ROMAN, conclusionFontSize, Font.NORMAL);

                        String title1 = "Andhra Pradesh Central Power Distribution Corporate Limited\n";

                        Paragraph title = new Paragraph(title1, titleFont);
                        title.setAlignment(Element.ALIGN_CENTER);
                        document.add(title);

                        String sub_title = "A Govt of A.P Enterprise & An ISO 9001:2015 & ISO @&001:2013 Certified Company\n\n";

                        Paragraph subTitle = new Paragraph(sub_title, subTitleFont);
                        subTitle.setAlignment(Element.ALIGN_CENTER);
                        document.add(subTitle);
                        Optional<UserDetails> optionalPatient = userDetailsRepository.findById(patientId);

                        String credit = "CREDIT CARD FOR TREATMENT";
                        Paragraph creditCard = new Paragraph(credit, titleFont);
                        creditCard.setAlignment(Element.ALIGN_CENTER);
                        document.add(creditCard);

                        String creditBody = "Credit card Serial No. MED161124135442";
                        Paragraph creditBody1 = new Paragraph(creditBody, subTitleFont);
                        creditBody1.setAlignment(Element.ALIGN_CENTER);
                        document.add(creditBody1);

                        String serialDet = "Letter.No.E-366767/EPCOR-06003(41)/32/2021-TR MEDICAL-COR/Dt.16-11-2024";
                        Paragraph serialDet1 = new Paragraph(serialDet, subTitleFont);
                        serialDet1.setAlignment(Element.ALIGN_CENTER);
                        document.add(serialDet1);

                        String from = "The Chief General\n" +
                                        "Manager (HRD)\n" +
                                        "Corporate Office\n" +
                                        "APCPDCL\n" +
                                        "Vijayawada";
                        String to = "The Director\n" +
                                        "M/S TIRUMALA MEDICOVER HOSPITALS\n" +
                                        "(SAHRUDHAYA HEALTHCARE VIJAYAWADA),\n" +
                                        "VIJAYAWADA\n" +
                                        "operatios.vzm@medicoverhospitals.in";

                        Paragraph fromAddress = new Paragraph("From:\n" + from, bodyFont);
                        fromAddress.setAlignment(Element.ALIGN_LEFT);
                        document.add(fromAddress);

                        Paragraph toHead = new Paragraph("\nTo\n", bodyFont);
                        toHead.setAlignment(Element.ALIGN_RIGHT);
                        toHead.setSpacingBefore(-5);
                        toHead.setIndentationRight(512);

                        document.add(toHead);

                        Paragraph toAddress = new Paragraph(to, bodyFont);
                        toAddress.setAlignment(Element.ALIGN_JUSTIFIED);
                        toAddress.setSpacingBefore(-8);
                        toAddress.setLeading(17f);
                        toAddress.setIndentationLeft(4);
                        document.add(toAddress);

                        org.springframework.core.io.Resource imageResource = new ClassPathResource(
                                        "picture/person.jpeg");
                        Image image = Image.getInstance(imageResource.getURL());
                        image.scaleToFit(150, 150);
                        image.setAlignment(Image.ALIGN_RIGHT);
                        image.setAbsolutePosition(400, 580);

                        document.add(image);

                        Font boldBodyFont = new Font(bodyFont.getFamily(), bodyFont.getSize(), Font.BOLD);
                        String ref = "Ref: Your Letter Dated: 16-Nov-2024\n\n";
                        Paragraph refpara = new Paragraph(ref, boldBodyFont);
                        refpara.setAlignment(Element.ALIGN_CENTER);
                        document.add(refpara);

                        if (optionalPatient.isPresent()) {
                                UserDetails patient = optionalPatient.get();
                                // Add patient details in a table
                                PdfPTable table = new PdfPTable(2);
                                table.setWidths(new float[] { 1f, 2f });
                                addTableRow(table, "Name of the Patient", patient.getPatientName(), bodyFont);
                                addTableRow(table, "Relation to the Employee", patient.getRelationToEmployee(),
                                                bodyFont);
                                addTableRow(table, "Name of the Employee (Employee ID)",
                                                patient.getEmployeeName() + " " + "(" + patient.getId() + ")",
                                                bodyFont);
                                addTableRow(table, "Designation", patient.getDesignation(), bodyFont);
                                addTableRow(table, "Office of the Employee", patient.getOffice(), bodyFont);
                                addTableRow(table, "Admission I.P No & Date", patient.getAdmissionDetails(), bodyFont);
                                addTableRow(table, "Disease", patient.getDisease(), bodyFont);
                                addTableRow(table, "Eligibility Amount", patient.getEligibilityAmount(), bodyFont);
                                document.add(table);
                        } else {
                                Paragraph error = new Paragraph("Patient details not found!", bodyFont);
                                error.setAlignment(Element.ALIGN_CENTER);
                                document.add(error);
                        }

                        String fline = "2) The above Credit card is issued with the approval of Competent authority.";
                        String sline = "3) Over and above eligibility amount may be collected from employee and APEPDCL (Board) will not accept any responsibility for excess amount billed.";
                        String tline = "4) Eligibility of Accomodation as per CGHS Tariff: General Ward per day.";
                        String foline = "5) Validity of Card: for one admission only for one month from the date of admission.";
                        String filine = "For any over stayal an extension card has to be applied for continuous treatment.";
                        String note = "Note:-";
                        String point1 = "i) Bill may be sent in duplicate along with discharge summary and copy of Case Sheet.No bill will be accepted for payment without producing discharge summary, copy if Case Sheet and signature of the Patient/Attendant. Also, the bank account details of the hospital should be fumished.";
                        String point2 = "ii) A copy of the Bill may also be issued to employee along with discharge summary.";
                        String point3 = "The Estimation for Credit Card and bills should be send with full Details and Particular as per CGHS-2014 Tariff Rates with code numbers and the Certificate regarding Non-NABH/NABL or NABH/NABL In term of the orders issued vide E.0.0. (HRD) Ms. No.82, Dt.12.05.15.";
                        String point4 = "iv) Also, the bank account detalls of the Hospital should be furnished.";

                        addLineToDocument(fline, document, bodyFont);
                        addLineToDocument(sline, document, bodyFont);
                        addLineToDocument(tline, document, bodyFont);
                        addLineToDocument(foline, document, bodyFont);
                        addLineToDocument(filine, document, bodyFont);
                        addLineToDocument(note, document, bodyFont);
                        addLineToDocument(point1, document, bodyFont);
                        addLineToDocument(point2, document, bodyFont);
                        addLineToDocument(point3, document, bodyFont);
                        addLineToDocument(point4, document, bodyFont);

                        String faithfully = "Yours faithfully,";
                        Paragraph faithfullyParagraph = new Paragraph(faithfully, bodyFont);
                        faithfullyParagraph.setAlignment(Element.ALIGN_RIGHT);
                        faithfullyParagraph.setIndentationRight(110);

                        BaseColor thickGreen = new BaseColor(0, 128, 0);
                        Font boldFont = new Font(bodyFont.getFamily(), bodyFont.getSize(), Font.BOLD);
                        Chunk nameAndDetails = new Chunk(
                                        "SUMAN KALYANI D (1019083)\nDesignation: CHIEF GENERAL MANAGER\nDate: Fri Nov 22 16:13:41 IST 2024",
                                        boldFont);
                        nameAndDetails.setFont(new Font(bodyFont.getFamily(), bodyFont.getSize(), bodyFont.getStyle(),
                                        thickGreen));
                        Paragraph nameAndDetailsParagraph = new Paragraph();
                        nameAndDetailsParagraph.add(nameAndDetails);
                        nameAndDetailsParagraph.setAlignment(Element.ALIGN_JUSTIFIED);

                        nameAndDetailsParagraph.setSpacingBefore(3);
                        nameAndDetailsParagraph.setIndentationLeft(300);

                        document.add(faithfullyParagraph);
                        document.add(nameAndDetailsParagraph);

                        String sign = "SIGNATURE OF THE OFFICER";
                        Paragraph sign1 = new Paragraph(sign, bodyFont);
                        sign1.setAlignment(Element.ALIGN_RIGHT);
                        sign1.setIndentationRight(110);
                        document.add(sign1);

                        String copyhead = "Copy to";
                        Paragraph copyhead1 = new Paragraph(copyhead, titleFont);
                        document.add(copyhead1);

                        String copy = "RAMANA V V (1019102), WATCHMAN, CORPORATE OFFICE \n THE EXECUTIVE ENGINEER, CORPORATE OFFICE";
                        Paragraph copy1 = new Paragraph(copy, bodyFont);
                        document.add(copy1);

                        String stock = "\nThe Stock file \n Self Funding Medical Scheme";
                        Paragraph stock1 = new Paragraph(stock, bodyFont);
                        document.add(stock1);

                        document.close();

                } catch (DocumentException e) {
                        System.out.println("Error occurred while generating the PDF file.");
                }

                return byteArrayOutputStream;
        }

        private void addTableRow(PdfPTable table, String key, String value, Font font) {

                PdfPCell keyCell = new PdfPCell(new Phrase(key, font));
                keyCell.setHorizontalAlignment(Element.ALIGN_LEFT);
                keyCell.setPadding(5);
                keyCell.setBorder(Rectangle.NO_BORDER);
                table.addCell(keyCell);

                PdfPCell valueCell = new PdfPCell(new Phrase(value, font));
                valueCell.setHorizontalAlignment(Element.ALIGN_LEFT);
                valueCell.setPadding(5);
                valueCell.setBorder(Rectangle.NO_BORDER);
                table.addCell(valueCell);
        }

        private void addLineToDocument(String line, Document document, Font font) throws DocumentException {
                Paragraph linePara = new Paragraph(line, font);
                linePara.setSpacingBefore(5);
                document.add(linePara);
        }
}
