package com.User.Pdf.Controller;

import com.User.Pdf.Service.PdfService;
import com.User.Pdf.Service.PdfService2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;

@RestController
@RequestMapping("/download")
public class PdfController {

    @Autowired
    private PdfService pdfService;

    @Autowired
    private PdfService2 pdfServices;

    @GetMapping("/pdf1")
    public ResponseEntity<byte[]> generatePdf() {

        ByteArrayOutputStream pdfBytes = pdfService.generatePdf1();

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Testing1.pdf");

        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE);

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes.toByteArray());
    }

    @GetMapping("/pdf2")
    public ResponseEntity<byte[]> generatePdfs() throws MalformedURLException, IOException {

        ByteArrayOutputStream pdfBytes = pdfServices.generatePdf(null);

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Testing2.pdf");

        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE);

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes.toByteArray());
    }

    @GetMapping("/pdf/generate/{patientId}")
    public ResponseEntity<byte[]> generatePdfByPatientId(@PathVariable Long patientId) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = pdfServices.generatePdf(patientId);

            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "inline; filename=patient_details.pdf");
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(byteArrayOutputStream.toByteArray());

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
