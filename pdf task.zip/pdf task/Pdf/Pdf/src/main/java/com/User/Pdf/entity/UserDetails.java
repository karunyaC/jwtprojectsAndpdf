package com.User.Pdf.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Setter
@Getter
@Table(name = "user_details")
public class UserDetails {
    @Id
    @Column(name = "id")
    private Long id;
    @Column(name = "patientName")
    private String patientName;
    @Column(name = "relationToEmployee")
    private String relationToEmployee;
    @Column(name = "employeeName")
    private String employeeName;
    @Column(name = "designation")
    private String designation;
    @Column(name = "office")
    private String office;
    @Column(name = "admissionDetails")
    private String admissionDetails;
    @Column(name = "disease")
    private String disease;
    @Column(name = "eligibilityAmount")
    private String eligibilityAmount;
}
