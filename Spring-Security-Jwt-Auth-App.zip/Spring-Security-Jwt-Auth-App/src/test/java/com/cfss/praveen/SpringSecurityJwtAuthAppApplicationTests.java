package com.cfss.praveen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityJwtAuthAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
