package com.cfss.praveen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cfss.praveen.entity.UserEntity;
import com.cfss.praveen.request.AuthRequest;
import com.cfss.praveen.service.JwtService;
import com.cfss.praveen.service.MyUserDetailsService;

import jakarta.security.auth.message.AuthException;

@RestController
@RequestMapping("/api")
public class UserRestController
{
	
	@Autowired
	private MyUserDetailsService userDtlsSvc;
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Autowired
	private AuthenticationManager authManager;
	
	@Autowired
	private JwtService jwtService;
	
	//register
	@GetMapping("/register")
	public String registerUser(UserEntity user)
	{
		String encodedPwd = encoder.encode(user.getUpwd());
		user.setUpwd(encodedPwd);
		
		boolean saveUser = userDtlsSvc.saveUser(user);
		
		if(saveUser)
			return "User Registered Sucessfully";
		else
			return "Registration Failed";
	}
	
	//login
	@PostMapping("/login")
	public String userAuthentication(AuthRequest request)
	{
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(request.getUname(), request.getUpwd());
		try
		{
			Authentication auth=authManager.authenticate(token);
			if(auth.isAuthenticated())
				return jwtService.generateToken(request.getUname());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "invalid";
		
	}
	
	//welcome
	@GetMapping("/welcome")
	public String welcome()
	{
		return "welcome";
	}
	
	//greet
	@GetMapping("/greet")
	public String greet()
	{
		return "Good Evening";
		
	}

	
}
