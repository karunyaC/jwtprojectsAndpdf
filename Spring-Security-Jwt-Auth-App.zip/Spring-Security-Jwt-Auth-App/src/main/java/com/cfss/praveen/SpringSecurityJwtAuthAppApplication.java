package com.cfss.praveen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityJwtAuthAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityJwtAuthAppApplication.class, args);
	}

}
