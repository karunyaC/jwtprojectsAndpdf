package com.cfss.praveen.service;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cfss.praveen.entity.UserEntity;
import com.cfss.praveen.repository.UserRepository;


@Service
public class MyUserDetailsService implements UserDetailsService
{
	@Autowired
	private UserRepository userRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
	{
		// TODO Auto-generated method stub
		
		UserEntity user=userRepo.findByUname(username);
		return new User(user.getUname(),user.getUpwd(),Collections.emptyList());
		
	}
	public boolean saveUser(UserEntity user)
	{
		user=userRepo.save(user);
		return user.getUserId()!=null;
	}
	

}
