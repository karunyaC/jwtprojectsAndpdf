package com.cfss.praveen.filter;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import com.cfss.praveen.service.JwtService;
import com.cfss.praveen.service.MyUserDetailsService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AppFilter  extends OncePerRequestFilter
{
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private MyUserDetailsService userDtlsSvc;
	
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		String token = request.getHeader("Authorization");
		String userName=null;
		if(token!=null)
		{
			token=token.substring(7);
			userName=jwtService.extractUsername(token);
		}
		if(userName!=null && SecurityContextHolder.getContext().getAuthentication()!=null)
		{
			UserDetails userDtls=userDtlsSvc.loadUserByUsername(userName);
			if(jwtService.validateToken(token, userDtls))
			{
				UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userName, userDtls);
				authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authenticationToken);
			}
		}
		filterChain.doFilter(request, response);
	}

}
