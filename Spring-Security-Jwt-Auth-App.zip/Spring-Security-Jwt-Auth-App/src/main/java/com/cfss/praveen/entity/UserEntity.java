package com.cfss.praveen.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="dev_users")
public class UserEntity
{
	@Id
	@GeneratedValue
	private Integer userId;
	private String uname;
	private String upwd;
	private Long phno;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpwd() {
		return upwd;
	}
	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}
	public Long getPhno() {
		return phno;
	}
	public void setPhno(Long phno) {
		this.phno = phno;
	}
	@Override
	public String toString() {
		return "UserEntity [userId=" + userId + ", uname=" + uname + ", upwd=" + upwd + ", phno=" + phno + "]";
	}
	
	
}
