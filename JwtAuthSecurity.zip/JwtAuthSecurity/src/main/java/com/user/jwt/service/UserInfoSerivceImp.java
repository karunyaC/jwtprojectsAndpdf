package com.user.jwt.service;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.user.jwt.config.UserInfoUserDetails;
import com.user.jwt.entity.UserInfo;
import com.user.jwt.repository.UserInfoRepository;
import java.util.*;
@Service
public class UserInfoSerivceImp implements UserDetailsService {

	@Autowired
	UserInfoRepository userInfoRepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<UserInfo> usInfo =userInfoRepository.findByUserName(username);
		
		return usInfo.map(UserInfoUserDetails::new).orElseThrow(() -> new UsernameNotFoundException("user not found "));
	}
	
	

}
