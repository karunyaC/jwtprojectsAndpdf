package com.user.jwt.service;

import java.security.Key;
import java.util.*;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtService {

	public static final String SECRET = "c5cc98688559b416da9c27938315458ade039779b1ecee472fbba3e90d6cdb60";

	public String extractUserName(String token) {
		return extractClaims(token, Claims::getSubject);
	}
	public Date extractExpairation(String token) {
		return extractClaims(token, Claims::getExpiration);
	}
	public boolean isTokenExpaired(String token) {
		return extractExpairation(token).before(new Date(0));
	}
	public boolean validateToken(String token,UserDetails userDetails) {
		final String userName =extractUserName(token);
		return (userName.equalsIgnoreCase(userDetails.getUsername()) && !isTokenExpaired(token));
	}
	public <T> T extractClaims(String token,Function<Claims, T> claimsResolved) {
		final Claims clams =extractAllClaims(token);
		return claimsResolved.apply(clams);
	}
	
	public Claims extractAllClaims(String token) {
		return Jwts
				.parserBuilder()
				.setSigningKey(getSigKey())
				.build()
				.parseClaimsJws(token)
				.getBody();
	}
	public String genarateToken(String userName) {
		Map<String, Object> claims = new HashMap<>();
		return createToken(claims,userName);
	}

	public String createToken(Map<String, Object> claims,String userName) {

		return Jwts.builder().setClaims(claims).setSubject(userName).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60))
				.signWith(getSigKey(), SignatureAlgorithm.HS256).compact();
	}

	private Key getSigKey() {
		byte[] getByteKey = Decoders.BASE64.decode(SECRET);
		return Keys.hmacShaKeyFor(getByteKey);
	}

}
