package com.user.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.jwt.entity.UserInfo;
import com.user.jwt.request.AuthenticateRequest;
import com.user.jwt.service.JwtService;
import com.user.jwt.service.UserInfoSerivce;
import com.user.jwt.service.UserInfoSerivceImp;

import io.jsonwebtoken.MissingClaimException;

@RestController
@RequestMapping("/auth")
public class UserInfoController {
	
	@Autowired
	UserInfoSerivce userInfoSerivce;
	@Autowired
	JwtService jwtService;
	
	@Autowired
	AuthenticationManager autManager;
	
	@GetMapping("/example")
	@PreAuthorize("hasRole('ROLE_USER')")
	public String getexampleValu() {
		String userName ="hi i have complete jwt token task in springSecurity";
		
		return " HelloWorld  \n"+userName;
	}
	@PostMapping("/newUser")
	public ResponseEntity<String> addNewUser(@RequestBody UserInfo userInfo) {
		return ResponseEntity.ok().body(userInfoSerivce.addNewUser(userInfo));
	}
	@PostMapping("/authenticate")
	public String userAuthenticate(@RequestBody AuthenticateRequest request) {
		Authentication authe =autManager.authenticate(new UsernamePasswordAuthenticationToken(request.getUserName(),request.getUserPassword()));
		if(authe.isAuthenticated()) {
			return jwtService.genarateToken(request.getUserName());
		}
		throw new UsernameNotFoundException("invalid user") ;
	
	}
}
