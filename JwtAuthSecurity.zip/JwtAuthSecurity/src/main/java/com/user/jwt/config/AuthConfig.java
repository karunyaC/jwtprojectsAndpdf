package com.user.jwt.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.user.jwt.filter.AuthFilter;
import com.user.jwt.service.JwtService;
import com.user.jwt.service.UserInfoSerivceImp;

@Configuration
public class AuthConfig {
	
	@Autowired
	JwtService jwtService;
	@Autowired
	AuthFilter authFilter;
	
	@Autowired
	UserInfoSerivceImp userInfoSerivceImp;
	
	@Bean
	public PasswordEncoder getEncoder() {
		return new  BCryptPasswordEncoder();
	}
	@Bean
	DaoAuthenticationProvider getAuthenticationProvider() {
		DaoAuthenticationProvider auProvider = new DaoAuthenticationProvider();
		auProvider.setUserDetailsService(userInfoSerivceImp);
		auProvider.setPasswordEncoder(getEncoder());
		return auProvider;
	}
	@Bean
	AuthenticationManager autManager(AuthenticationConfiguration config) throws Exception {
		return	config.getAuthenticationManager();
	}
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		return http
				.csrf()
				.disable()
				.authorizeHttpRequests()
				.requestMatchers("/auth/authenticate","/auth/newUser")
				.permitAll()
				.and()
				.authorizeHttpRequests()
				.requestMatchers("/auth/**")
				.authenticated()
				.and()
				.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
				.authenticationProvider(getAuthenticationProvider())
				.addFilterBefore(authFilter,UsernamePasswordAuthenticationFilter.class)
				.build();
	}

}
