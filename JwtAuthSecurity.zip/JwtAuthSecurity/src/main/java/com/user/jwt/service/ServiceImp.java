package com.user.jwt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.user.jwt.entity.UserInfo;
import com.user.jwt.repository.UserInfoRepository;
import java.util.*;
@Service
public class ServiceImp implements UserInfoSerivce{
	@Autowired
	UserInfoRepository uRepository;

	@Autowired
	PasswordEncoder passwordEncoder;
	
	public	boolean flag;
	
	@Override
	public String addNewUser(UserInfo userInfo) {
		List<UserInfo> usList =uRepository.findAll();
		
		for(UserInfo user :usList) {
			if(user.getUserName().equalsIgnoreCase(userInfo.getUserName())) {
				 flag =true;
			}else {
				flag =false; 
			}
		}
		if(flag) {
			return "User already exist ";
		}else {
			userInfo.setUserPassword(passwordEncoder.encode(userInfo.getUserPassword()));
			uRepository.save(userInfo);
			return "user Register successfully";
		}
	}
	
	

}
