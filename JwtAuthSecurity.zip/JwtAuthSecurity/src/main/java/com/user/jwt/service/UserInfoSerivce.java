package com.user.jwt.service;

import com.user.jwt.entity.UserInfo;

public interface UserInfoSerivce {

	String addNewUser(UserInfo userInfo);

}
